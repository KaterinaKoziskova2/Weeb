const express = require('express')
const session = require('express-session')
const bcrypt = require('bcrypt')
const sqlite3 = require('sqlite3').verbose()
const path = require('path')
const app = express()

const db = new sqlite3.Database('./db/database.db')

app.set('view engine', 'ejs')
app.use(express.static('public'))
app.use(express.urlencoded({ extended: true }))

app.use(session({
    secret: 'tajny-klic',
    resave: false,
    saveUninitialized: false
}))

function requireLogin(req, res, next) {
    if (!req.session.user) return res.redirect('/login')
    next()
}

app.get('/', (req, res) => res.redirect('/products'))

app.get('/register', (req, res) => res.render('register'))
app.post('/register', async (req, res) => {
    const { username, password, vip } = req.body
    const hashedPassword = await bcrypt.hash(password, 10)
    const isVip = vip === 'on' ? 1 : 0
    db.run('INSERT INTO users (username, password, is_vip) VALUES (?, ?, ?)', [username, hashedPassword, isVip], err => {
        if (err) return res.send('Uživatel už existuje')
        res.redirect('/login')
    })
})

app.get('/login', (req, res) => res.render('login'))
app.post('/login', (req, res) => {
    const { username, password } = req.body
    db.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.send('Neplatné přihlašovací údaje')
        }
        req.session.user = user
        res.redirect('/products')
    })
})

app.get('/logout', (req, res) => {
    req.session.destroy(() => res.redirect('/login'))
})

app.get('/products', requireLogin, (req, res) => {
    db.all('SELECT * FROM products', (err, products) => {
        res.render('products', { products, user: req.session.user })
    })
})

app.post('/add-to-cart', requireLogin, (req, res) => {
    const userId = req.session.user.id
    const { product_id } = req.body
    db.get('SELECT * FROM cart WHERE user_id = ? AND product_id = ?', [userId, product_id], (err, row) => {
        if (row) {
            db.run('UPDATE cart SET quantity = quantity + 1 WHERE id = ?', [row.id], () => res.redirect('/cart'))
        } else {
            db.run('INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, 1)', [userId, product_id], () => res.redirect('/cart'))
        }
    })
})

app.get('/cart', requireLogin, (req, res) => {
    const userId = req.session.user.id
    const isVip = req.session.user.is_vip === 1
    const sql = `SELECT cart.id, products.name, products.price, products.image, cart.quantity FROM cart
                 JOIN products ON cart.product_id = products.id WHERE cart.user_id = ?`
    db.all(sql, [userId], (err, items) => {
        let total = 0
        items.forEach(item => {
            let price = item.price
            if (isVip) price *= 0.7
            if (item.quantity >= 10) price *= 0.9
            item.finalPrice = (price * item.quantity).toFixed(2)
            total += parseFloat(item.finalPrice)
        })
        res.render('cart', { items, total: total.toFixed(2) })
    })
})

app.listen(3000)